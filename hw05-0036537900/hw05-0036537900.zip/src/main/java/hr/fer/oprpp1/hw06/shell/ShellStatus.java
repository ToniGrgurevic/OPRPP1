package hr.fer.oprpp1.hw06.shell;

public enum ShellStatus {
    CONTINUE, TERMINATE
}
