package hr.fer.oprpp1.hw06.shell;

public class ShellIOException extends RuntimeException {
    public ShellIOException(String s) {
        super(s);
    }
}
