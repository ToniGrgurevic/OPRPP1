package hr.fer.oprpp1.hw04.db;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.Format;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentDB {


    public static void main(String[] args) throws IOException {

        var list = Files.readAllLines(Paths.get("src/main/resources/database.txt")
                                                , StandardCharsets.UTF_8);

        StudentDatabase db = new StudentDatabase(list.toArray(new String[0]));

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.print(">");
            String input = sc.nextLine();
            if (input.strip().startsWith("exit"))
                break;

            if (input.strip().startsWith("query")) {
                input = input.strip().substring("query".length());

                QueryParser parser;
                try{
                    parser = new QueryParser(input);
                }catch (IllegalArgumentException e){
                    System.out.println("Invalid query,try again."+e.getMessage());
                    continue;
                }


                List<StudentRecord> filtered;
                if(parser.isDirectQuery()){
                    filtered = new ArrayList<>();
                    filtered.add(db.forJMBAG(parser.getQueriedJMBAG()));
                    if(filtered.get(0) == null)
                        filtered.remove(0);
                    else
                        System.out.println("Using index for record retrieval.");
                }else
                    filtered = filter(input, db,parser);



                List<String> formated = StudentDB.formatOutput(filtered);

                for (var s : formated) {
                        System.out.println(s);
                    }
                System.out.println("Records selected: " + filtered.size());
                System.out.println();

            } else {
                System.out.println("Invalid command,try again.");
            }
        }
        System.out.println("Goodbye!");
    }

    private static List<String> formatOutput(List<StudentRecord> filtered) {
        if(filtered.isEmpty()) return new ArrayList<>();

        List<String> output = new ArrayList<String>();
        int maxSizeFirstName = 10;
        int maxSizeLastName = 10;
        for(var student : filtered){
            if(student.getFirstName().length() > maxSizeFirstName)
                maxSizeFirstName = student.getFirstName().length();
            if(student.getLastName().length() > maxSizeLastName)
                maxSizeLastName = student.getLastName().length();
        }

        StringBuilder okvir = new StringBuilder();
        okvir.append("+")
                .append("=".repeat(12))
                .append("+")
                .append("=".repeat(Math.max(0, maxSizeLastName + 2)))
                .append("+")
                .append("=".repeat(Math.max(0, maxSizeFirstName + 2)))
                .append("+===+");
        output.add(okvir.toString());
        for(var student : filtered){
            StringBuilder sb = new StringBuilder();
            sb.append("| ").append(student.getJmbag()).append(" | ").append(student.getLastName());
            sb.append(" ".repeat(Math.max(0, maxSizeLastName - student.getLastName().length())));
            sb.append(" | ").append(student.getFirstName());
            sb.append(" ".repeat(Math.max(0, maxSizeFirstName - student.getFirstName().length())));
            sb.append(" | ").append(student.getGrade()).append(" |");

            output.add(sb.toString());
        }
        output.add(okvir.toString());
        return  output;

    }



    /**
     * Method that filters students from database with given filter
     * @param input input from user that contains conditions
     * @param db database
     * @return list of students that satisfy user conditions
     */
    private static List<StudentRecord> filter(String input, StudentDatabase db,QueryParser parser) {

        IFilter filter = new QueryFilter(parser.getQuery());

        return db.filter(filter);
    }



}