package hr.fer.oprpp1.hw02.prob1;

/**
 * States in witch lexer can be.
 */
public enum LexerState {
    BASIC, EXTENDED
}
