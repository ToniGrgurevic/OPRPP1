package hr.fer.oprpp1.custom.scripting.elems;

/**
 *  used to for the representation of expressions
 */
public class Element {






    public String asText(){
        return "";
    }
}
