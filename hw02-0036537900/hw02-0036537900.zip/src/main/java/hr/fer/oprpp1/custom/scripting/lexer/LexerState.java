package hr.fer.oprpp1.custom.scripting.lexer;

/**
 * States in witch lexer can be.
 */
public enum LexerState {
    BASIC, TAG
}
