package hr.fer.oprpp1.jmbag0036537900.collections;

/**
 * Object of this class  knows how to process some other object
 */
public class Processor {

    /**
     * Method that processes the given value
     * @param value to be processed
     */
    public void process(Object value){}
}


